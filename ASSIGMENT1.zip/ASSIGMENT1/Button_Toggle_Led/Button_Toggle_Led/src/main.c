/*
 * main.c
 *
 * Created on: 25 thg 9, 2025
 *      Author: nguyen sy hung
 *
 * Ví dụ ứng dụng sử dụng Driver_PORT_S32K144 và Driver_GPIO
 * chuẩn CMSIS cho S32K144
 * Chức năng demo:
 * Sử dụng 2 nút nhấn BT1, BT2 tích hợp trên board.
 * BT1: Toggle LED đỏ (PTD15).
 * BT2: Toggle LED xanh lá (PTD16).
 * Luồng xử lý:
 * Bật clock cho PORTC và PORTD.
 * Cấu hình pin LED (PTD15, PTD16) là GPIO output.
 * Cấu hình pin nút nhấn (PTC12, PTC13) là GPIO input + interrupt.
 * Đăng ký callback để xử lý sự kiện nhấn nút:
 * Khi BT1 bấm (cạnh xuống): LED đỏ đổi trạng thái.
 * Khi BT2 bấm (cạnh xuống): LED xanh lá đổi trạng thái.
 */


#include "Driver_GPIO.h"
#include "Driver_PORT_S32K144.h"
#include "Driver_GPIO_Pins.h"

extern ARM_DRIVER_GPIO Driver_GPIO0;
extern ARM_DRIVER_PORT Driver_PORT0;

/* Callback cho BT1 và BT2 */
void button_callback(ARM_GPIO_Pin_t pin, uint32_t event) {
    static uint32_t red_state = 0;
    static uint32_t green_state = 0;

    if (event == ARM_GPIO_EVENT_FALLING_EDGE) {
        if (pin == GPIO_PIN_BT1) {
            red_state ^= 1;
            Driver_GPIO0.SetOutput(GPIO_PIN_LED_RED, red_state);
        }
        else if (pin == GPIO_PIN_BT2) {
            green_state ^= 1;
            Driver_GPIO0.SetOutput(GPIO_PIN_LED_GREEN, green_state);
        }
    }
}

int main(void) {
    /* ===== Enable Clock cho PORTC và PORTD ===== */
    Driver_PORT0.EnableClock(PORTC_INDEX);
    Driver_PORT0.EnableClock(PORTD_INDEX);

    /* ===== Setup LED RED (PTD15) ===== */
    Driver_PORT0.SetMux(GPIO_PIN_LED_RED, ARM_PORT_MUX_GPIO);
    Driver_GPIO0.Setup(GPIO_PIN_LED_RED, NULL);
    Driver_GPIO0.SetDirection(GPIO_PIN_LED_RED, ARM_GPIO_OUTPUT);

    /* ===== Setup LED GREEN (PTD16) ===== */
    Driver_PORT0.SetMux(GPIO_PIN_LED_GREEN, ARM_PORT_MUX_GPIO);
    Driver_GPIO0.Setup(GPIO_PIN_LED_GREEN, NULL);
    Driver_GPIO0.SetDirection(GPIO_PIN_LED_GREEN, ARM_GPIO_OUTPUT);

    /* ===== Setup Button BT1 (PTC13) ===== */
    Driver_PORT0.SetMux(GPIO_PIN_BT1, ARM_PORT_MUX_GPIO);
    Driver_GPIO0.Setup(GPIO_PIN_BT1, button_callback);
    Driver_GPIO0.SetDirection(GPIO_PIN_BT1, ARM_GPIO_INPUT);
    Driver_GPIO0.SetPullResistor(GPIO_PIN_BT1, ARM_GPIO_PULL_UP);
    Driver_GPIO0.SetEventTrigger(GPIO_PIN_BT1, ARM_GPIO_TRIGGER_FALLING_EDGE);

    /* ===== Setup Button BT2 (PTC12) ===== */
    Driver_PORT0.SetMux(GPIO_PIN_BT2, ARM_PORT_MUX_GPIO);
    Driver_GPIO0.Setup(GPIO_PIN_BT2, button_callback);
    Driver_GPIO0.SetDirection(GPIO_PIN_BT2, ARM_GPIO_INPUT);
    Driver_GPIO0.SetPullResistor(GPIO_PIN_BT2, ARM_GPIO_PULL_UP);
    Driver_GPIO0.SetEventTrigger(GPIO_PIN_BT2, ARM_GPIO_TRIGGER_FALLING_EDGE);

    while (1) {
     // chờ ngắt
    }
}
